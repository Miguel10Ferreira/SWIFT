import UIKit

extension UIScrollView {
    var hasScrolledToBottom: Bool { contentSize.height - contentOffset.y < frame.size.height * 1.6 }
}
