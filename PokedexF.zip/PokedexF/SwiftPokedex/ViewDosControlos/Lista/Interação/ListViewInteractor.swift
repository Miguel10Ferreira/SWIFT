import UIKit

protocol ListViewInteractable {
    func selectItem(at indexPath: IndexPath, in tableView: UITableView)
}

final class ListViewInteractor: ListViewInteractable {
    
    private let router: ListViewRoutable
    
    init(router: ListViewRoutable) {
        self.router = router
    }
    
    func selectItem(at indexPath: IndexPath, in tableView: UITableView) {
        guard let cell = tableView.cell(at: indexPath) as? RegularCell,
              let itemData = cell.data
        else { return }

        router.routeToItemList(with: itemData)
    }
}
