import UIKit

extension ItemsViewController {
    
    struct ViewModel {
        let title: String?
        var cleanTitle: String? { title?.cleaned }
    }
}
