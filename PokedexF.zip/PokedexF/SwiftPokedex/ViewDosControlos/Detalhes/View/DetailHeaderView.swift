import UIKit

final class DetailHeaderView: UIView {
    
    private lazy var imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    init(frame: CGRect, urlString: String, color: UIColor) {
        super.init(frame: frame)
        
        backgroundColor = .darkGrey
        
        let fillerView = UIView(frame: UIScreen.main.bounds)
        fillerView.backgroundColor = color
        fillerView.frame.origin.y -= fillerView.frame.height - frame.height
        fillerView.roundedView(corners: [.bottomLeft, .bottomRight], radius: 40.0)
        addSubview(fillerView)

        addSubview(imageView)

        UIImage.load(from: urlString) { [weak self] image in
            DispatchQueue.main.async { self?.imageView.image = image }
        }
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        imageView.frame = frame
    }
}
